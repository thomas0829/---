#!/usr/bin/env python3

import rospy
import actionlib
import time
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import PoseWithCovarianceStamped


class SendGoalCycle:
    def __init__(self):
        # 初始化ROS節點
        rospy.init_node('send_goal_cycle')

        # 創建一個SimpleActionClient來與move_base進行通信
        self.client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        self.client.wait_for_server()

        # 設置目標點列表
        self.goals = [
            {'x': 3.0, 'y': 1.0, 'w': 1.0},
            {'x': 5.0, 'y': 3.0, 'w': 1.0},
            {'x': 0.0, 'y': 0.0, 'w': 1.0},
            {'x': 0.0, 'y': 0.0, 'w': 1.0}
        ]

        # 訂閱AMCL的定位話題以監控定位狀態
        self.initialized = False
        rospy.Subscriber("/amcl_pose", PoseWithCovarianceStamped, self.pose_callback)

        rospy.loginfo("Waiting for localization to complete...")
        rospy.spin()

    def pose_callback(self, data):
        if not self.initialized:
            self.initialized = True
            rospy.loginfo("Localization complete. Starting navigation cycle...")
            self.navigate_cycle()

    def send_goal(self, x, y, w):
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()

        # 設置目標點的坐標和方向
        goal.target_pose.pose.position.x = x
        goal.target_pose.pose.position.y = y
        goal.target_pose.pose.orientation.w = w

        rospy.loginfo(f"Sending goal: x={x}, y={y}, w={w}")
        self.client.send_goal(goal)
        self.client.wait_for_result()

        rospy.loginfo("Goal reached. Waiting for 3 seconds...")
        time.sleep(3)

    def navigate_cycle(self):
        while not rospy.is_shutdown():
            for goal in self.goals:
                self.send_goal(goal['x'], goal['y'], goal['w'])
                

if __name__ == '__main__':
    try:
        SendGoalCycle()
    except rospy.ROSInterruptException:
        rospy.loginfo("Navigation test finished.")